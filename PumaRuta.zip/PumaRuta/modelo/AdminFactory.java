package modelo;

public class AdminFactory implements UsuarioFactory {
    @Override
    public Usuario crearUsuario(String nombre) {
        return new UsuarioAdmin(nombre);
    }
}