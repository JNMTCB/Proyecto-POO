package modelo;

public class ClienteFactory implements UsuarioFactory {
    @Override
    public Usuario crearUsuario(String nombre) {
        return new UsuarioCliente(nombre);
    }
}