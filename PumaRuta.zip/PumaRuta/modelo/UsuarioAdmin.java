package modelo;

public class UsuarioAdmin extends Usuario {

    public UsuarioAdmin(String nombre) {
        super(nombre, "admin");
    }

    @Override
    public void mostrarMenu() {
        System.out.println("=== Menú de Administrador ===");
        System.out.println("1. Cargar líneas y paradas");
        System.out.println("2. Agregar destino");
        System.out.println("3. Consultar rutas");
        System.out.println("4. Salir");
    }
}