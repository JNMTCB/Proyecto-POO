package modelo;

public class UsuarioFactoryProvider {
    public static UsuarioFactory getFactory(String tipo) {
        if (tipo.equalsIgnoreCase("admin")) {
            return new AdminFactory();
        } else {
            return new ClienteFactory();
        }
    }
}