package modelo;

import java.util.List;

public class Ruta {
    private String nombre;
    private String color;
    private List<Parada> paradas;

    public Ruta(String nombre, String color, List<Parada> paradas) {
        this.nombre = nombre;
        this.color = color;
        this.paradas = paradas;
    }

    public String getNombre() {
        return nombre;
    }

    public String getColor() {
        return color;
    }

    public List<Parada> getParadas() {
        return paradas;
    }
}