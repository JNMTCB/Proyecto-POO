package modelo;

public class UsuarioCliente extends Usuario {

    public UsuarioCliente(String nombre) {
        super(nombre, "cliente");
    }

    @Override
    public void mostrarMenu() {
        System.out.println("=== Menú de Usuario ===");
        System.out.println("1. Consultar ruta");
        System.out.println("2. Salir");
    }
}