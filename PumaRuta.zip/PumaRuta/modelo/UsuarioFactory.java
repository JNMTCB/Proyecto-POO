package modelo;

public interface UsuarioFactory {
    Usuario crearUsuario(String nombre);
}