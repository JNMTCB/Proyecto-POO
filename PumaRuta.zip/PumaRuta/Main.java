import modelo.Usuario;
import modelo.Ruta;
import servicio.GestorUsuarios;
import servicio.SistemaPumaRuta;
import estrategia.BuscadorDeRutas;
import estrategia.RutaDirectaStrategy;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GestorUsuarios gestorUsuarios = new GestorUsuarios();
        SistemaPumaRuta sistema = new SistemaPumaRuta();
        BuscadorDeRutas buscador = new BuscadorDeRutas();

        System.out.println("Bienvenido al Sistema PumaRuta");

        Usuario usuario = null;
        while (usuario == null) {
            System.out.print("Ingresa tu nombre de usuario: ");
            String nombre = scanner.nextLine();

            if (!gestorUsuarios.existeUsuario(nombre)) {
                System.out.println("Usuario no encontrado. ¿Deseas registrarte? (s/n)");
                String respuesta = scanner.nextLine();
                if (respuesta.equalsIgnoreCase("s")) {
                    System.out.print("¿Eres admin o cliente? ");
                    String tipo = scanner.nextLine();
                    gestorUsuarios.registrarUsuario(nombre, tipo);
                    usuario = gestorUsuarios.iniciarSesion(nombre);
                }
            } else {
                usuario = gestorUsuarios.iniciarSesion(nombre);
            }
        }

        System.out.println("\n¡Bienvenido, " + usuario.getNombre() + "!");

        boolean activo = true;
        while (activo) {
            usuario.mostrarMenu();
            System.out.print("Selecciona una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // limpiar buffer

            if (usuario.getTipo().equals("cliente")) {
                switch (opcion) {
                    case 1:
                        System.out.println("\nParadas disponibles:");
                        sistema.getTodasLasParadas().forEach(p -> System.out.println(" - " + p));

                        System.out.print("\nEntrada (parada inicial): ");
                        String entrada = scanner.nextLine().trim();

                        System.out.print("Destino (parada final): ");
                        String destino = scanner.nextLine().trim();

                        buscador.setEstrategia(new RutaDirectaStrategy());
                        List<Ruta> rutas = buscador.buscarRutas(sistema.getRutas(), entrada, destino);

                        if (rutas.isEmpty()) {
                            System.out.println("\nNo se encontró una ruta directa entre \"" + entrada + "\" y \"" + destino + "\"");
                            System.out.println("Sugerencia: Verifique que los nombres coincidan con las paradas listadas.");
                        } else {
                            System.out.println("\nRutas disponibles:");
                            for (Ruta r : rutas) {
                                System.out.println("- " + r.getNombre() + " (" + r.getColor() + ")");
                                System.out.println("  Paradas:");
                                r.getParadas().forEach(p -> System.out.println("    • " + p.getNombre()));
                            }
                        }
                        break;
                    case 2:
                        activo = false;
                        break;
                    default:
                        System.out.println("Opción no válida.");
                }
            }
        }

        System.out.println("Gracias por usar PumaRuta.");
    }
}
