package servicio;

import modelo.Ruta;
import modelo.Parada;
import java.util.ArrayList;
import java.util.List;

public class CargadorRutas {
    private SistemaPumaRuta sistema;

    public CargadorRutas(SistemaPumaRuta sistema) {
        this.sistema = sistema;
    }

    public void cargarRuta(String nombre, String color, List<String> nombresParadas) {
        List<Parada> paradas = new ArrayList<>();
        for (String nombreParada : nombresParadas) {
            paradas.add(new Parada(nombreParada));
        }
        
        Ruta nuevaRuta = new Ruta(nombre, color, paradas);
        sistema.agregarRuta(nuevaRuta);
    }

    public void agregarParadaARuta(String nombreRuta, String nombreParada) {
        for (Ruta ruta : sistema.getRutas()) {
            if (ruta.getNombre().equals(nombreRuta)) {
                ruta.getParadas().add(new Parada(nombreParada));
                break;
            }
        }
    }
}
