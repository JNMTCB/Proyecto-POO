package servicio;

import modelo.*;
import java.util.HashMap;
import java.util.Map;

public class GestorUsuarios {
    private Map<String, Usuario> usuarios;

    public GestorUsuarios() {
        this.usuarios = new HashMap<>();
    }

    public boolean existeUsuario(String nombre) {
        return usuarios.containsKey(nombre);
    }

    public void registrarUsuario(String nombre, String tipo) {
        UsuarioFactory factory = UsuarioFactoryProvider.getFactory(tipo);
        Usuario usuario = factory.crearUsuario(nombre);
        usuarios.put(nombre, usuario);
    }

    public Usuario iniciarSesion(String nombre) {
        return usuarios.get(nombre);
    }
}
