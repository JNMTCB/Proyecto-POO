package servicio;

import modelo.Ruta;
import modelo.Parada;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.stream.Collectors;

public class SistemaPumaRuta {
    private List<Ruta> rutas;

    public SistemaPumaRuta() {
        this.rutas = new ArrayList<>();
        inicializarRutas();
    }

    private void inicializarRutas() {
        // Ruta 1: Metro CU -> Facultad de Ingeniería
        List<Parada> paradasRuta1 = new ArrayList<>();
        paradasRuta1.add(new Parada("Metro CU"));
        paradasRuta1.add(new Parada("Ciudad Universitaria"));
        paradasRuta1.add(new Parada("Facultad de Ingeniería"));
        paradasRuta1.add(new Parada("Facultad de Medicina"));
        
        // Ruta 2: Metro Universidad -> Facultad de Ingeniería
        List<Parada> paradasRuta2 = new ArrayList<>();
        paradasRuta2.add(new Parada("Metro Universidad"));
        paradasRuta2.add(new Parada("Estadio Olímpico"));
        paradasRuta2.add(new Parada("Rectoría"));
        paradasRuta2.add(new Parada("Facultad de Ingeniería"));

        rutas.add(new Ruta("Ruta 1", "Azul", paradasRuta1));
        rutas.add(new Ruta("Ruta 2", "Rojo", paradasRuta2));
    }

    public List<Ruta> getRutas() {
        return rutas;
    }

    public void agregarRuta(Ruta ruta) {
        rutas.add(ruta);
    }

    public Set<String> getTodasLasParadas() {
        Set<String> paradas = new HashSet<>();
        for (Ruta ruta : rutas) {
            for (Parada parada : ruta.getParadas()) {
                paradas.add(parada.getNombre());
            }
        }
        return paradas;
    }
}
