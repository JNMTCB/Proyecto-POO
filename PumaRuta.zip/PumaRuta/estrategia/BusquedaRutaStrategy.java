package estrategia;

import modelo.Ruta;
import java.util.List;

public interface BusquedaRutaStrategy {
    List<Ruta> buscar(List<Ruta> rutasDisponibles, String entrada, String destino);
}