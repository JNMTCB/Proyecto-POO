package estrategia;

import modelo.Ruta;
import modelo.Parada;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.text.Normalizer;

public class RutaDirectaStrategy implements BusquedaRutaStrategy {
    @Override
    public List<Ruta> buscar(List<Ruta> rutasDisponibles, String entrada, String destino) {
        List<Ruta> resultado = new ArrayList<>();
        
        // Normalizar entrada y destino
        entrada = normalizar(entrada);
        destino = normalizar(destino);

        for (Ruta ruta : rutasDisponibles) {
            List<String> nombresParadas = ruta.getParadas()
                .stream()
                .map(p -> normalizar(p.getNombre()))
                .collect(Collectors.toList());

            // Verificar si la ruta contiene tanto la entrada como el destino
            int indiceEntrada = -1;
            int indiceDestino = -1;

            // Buscar coincidencias aproximadas
            for (int i = 0; i < nombresParadas.size(); i++) {
                String parada = nombresParadas.get(i);
                if (parada.equals(entrada)) {
                    indiceEntrada = i;
                }
                if (parada.equals(destino)) {
                    indiceDestino = i;
                }
            }

            // La ruta es válida si contiene ambas paradas y la entrada está antes que el destino
            if (indiceEntrada != -1 && indiceDestino != -1 && indiceEntrada < indiceDestino) {
                resultado.add(ruta);
            }
        }
        
        return resultado;
    }

    private String normalizar(String texto) {
        // Convertir a minúsculas, eliminar acentos y espacios extra
        String normalizado = Normalizer.normalize(texto, Normalizer.Form.NFD)
            .replaceAll("\\p{InCombiningDiacriticalMarks}+", "")
            .toLowerCase()
            .trim()
            .replaceAll("\\s+", " ");
        return normalizado;
    }
}
