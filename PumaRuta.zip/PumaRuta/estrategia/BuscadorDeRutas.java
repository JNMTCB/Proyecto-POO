package estrategia;

import modelo.Ruta;
import java.util.List;

public class BuscadorDeRutas {
    private BusquedaRutaStrategy estrategia;

    public void setEstrategia(BusquedaRutaStrategy estrategia) {
        this.estrategia = estrategia;
    }

    public List<Ruta> buscarRutas(List<Ruta> rutasDisponibles, String entrada, String destino) {
        return estrategia.buscar(rutasDisponibles, entrada, destino);
    }
}