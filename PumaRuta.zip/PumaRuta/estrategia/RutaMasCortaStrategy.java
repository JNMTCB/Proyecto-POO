package estrategia;

import modelo.Ruta;
import java.util.Comparator;
import java.util.List;

public class RutaMasCortaStrategy implements BusquedaRutaStrategy {
    @Override
    public List<Ruta> buscar(List<Ruta> rutasDisponibles, String entrada, String destino) {
        return rutasDisponibles.stream()
            .filter(r -> r.getParadas().stream().anyMatch(p -> p.getNombre().equalsIgnoreCase(entrada)) &&
                         r.getParadas().stream().anyMatch(p -> p.getNombre().equalsIgnoreCase(destino)))
            .sorted(Comparator.comparingInt(r -> r.getParadas().size()))
            .limit(1)
            .toList();
    }
}