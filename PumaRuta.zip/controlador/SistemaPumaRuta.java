package controlador;

import modelo.*;
import java.util.*;
import excepciones.AccesoDenegadoException;

public class SistemaPumaRuta {
    private static SistemaPumaRuta instancia;
    private List<Linea> lineas;
    private List<Entrada> entradas;
    private List<Destino> destinos;

    private SistemaPumaRuta() {
        inicializarDatos();
    }

    public static SistemaPumaRuta getInstancia() {
        if (instancia == null) {
            instancia = new SistemaPumaRuta();
        }
        return instancia;
    }

    private void inicializarDatos() {
        // Entradas
        entradas = Arrays.asList(
            new Entrada("Metro Universidad"),
            new Entrada("Metrobús CU"),
            new Entrada("Av. del Imán"),
            new Entrada("Delfín Madrigal"),
            new Entrada("Copilco")
        );

        // Destinos
        destinos = Arrays.asList(
            new Destino("Alberca Olímpica"),
            new Destino("Facultad de Ingeniería"),
            new Destino("Las Islas"),
            new Destino("Estadio Olímpico"),
            new Destino("Facultad de Medicina")
        );

        // Líneas y paradas hardcodeadas (ejemplo)
        lineas = new ArrayList<>();

        Linea linea1 = new Linea("Línea 1");
        linea1.agregarParada(new Parada("Metro Universidad"));
        linea1.agregarParada(new Parada("Islas"));
        linea1.agregarParada(new Parada("Alberca Olímpica"));
        linea1.agregarParada(new Parada("Facultad de Ingeniería"));
        linea1.agregarParada(new Parada("Estadio Olímpico"));
        linea1.agregarParada(new Parada("Metro Universidad"));

        Linea linea3 = new Linea("Línea 3");
        linea3.agregarParada(new Parada("Metrobús CU"));
        linea3.agregarParada(new Parada("Estadio de Prácticas"));
        linea3.agregarParada(new Parada("Las Islas"));
        linea3.agregarParada(new Parada("Facultad de Medicina"));
        linea3.agregarParada(new Parada("Metrobús CU"));

        lineas.add(linea1);
        lineas.add(linea3);
    }

    public List<Entrada> getEntradas() { return entradas; }
    public List<Destino> getDestinos() { return destinos; }
    public List<Linea> getLineas() { return lineas; }

    public Ruta buscarRuta(String entradaNombre, String destinoNombre) throws AccesoDenegadoException {
        Entrada entrada = entradas.stream().filter(e -> e.getNombre().equalsIgnoreCase(entradaNombre)).findFirst().orElse(null);
        Destino destino = destinos.stream().filter(d -> d.getNombre().equalsIgnoreCase(destinoNombre)).findFirst().orElse(null);

        if (entrada == null || destino == null)
            throw new AccesoDenegadoException("Entrada o destino no encontrado.");

        // Búsqueda muy básica (puedes mejorar después con transbordos)
        for (Linea linea : lineas) {
            boolean tieneEntrada = linea.getParadas().stream().anyMatch(p -> p.getNombre().equalsIgnoreCase(entrada.getNombre()));
            boolean tieneDestino = linea.getParadas().stream().anyMatch(p -> p.getNombre().equalsIgnoreCase(destino.getNombre()));

            if (tieneEntrada && tieneDestino) {
                // Si el destino viene después de la entrada, funciona
                int idxEntrada = -1, idxDestino = -1;
                for (int i = 0; i < linea.getParadas().size(); i++) {
                    if (linea.getParadas().get(i).getNombre().equalsIgnoreCase(entrada.getNombre())) idxEntrada = i;
                    if (linea.getParadas().get(i).getNombre().equalsIgnoreCase(destino.getNombre())) idxDestino = i;
                }
                if (idxEntrada != -1 && idxDestino != -1 && idxDestino > idxEntrada) {
                    return new Ruta(entrada, destino, linea, linea.getParadas().get(idxEntrada), linea.getParadas().get(idxDestino));
                }
            }
        }
        // Si no encontró directa, retorna alternativa
        Ruta ruta = new Ruta(entrada, destino, lineas.get(0), new Parada(entrada.getNombre()), new Parada(destino.getNombre()));
        ruta.setAlternativa("No hay ruta directa, podría requerir transbordo o caminar.");
        return ruta;
    }
}