package persistencia;

import modelo.Usuario;
import modelo.Administrador;
import modelo.Cliente;
import excepciones.UsuarioExistenteException;
import excepciones.UsuarioNoEncontradoException;

import java.io.*;
import java.util.HashMap;

public class GestorUsuarios {
    private static final String ARCHIVO_USUARIOS = "usuarios.dat";
    private HashMap<String, Usuario> usuarios;

    public GestorUsuarios() {
        usuarios = new HashMap<>();
        cargarUsuarios();
    }

    public void registrarUsuario(Usuario usuario) throws UsuarioExistenteException {
        if (usuarios.containsKey(usuario.getNombreUsuario())) {
            throw new UsuarioExistenteException("El usuario ya existe.");
        }
        usuarios.put(usuario.getNombreUsuario(), usuario);
        guardarUsuarios();
    }

    public Usuario autenticar(String nombreUsuario, String contraseña) throws UsuarioNoEncontradoException {
        if (usuarios.containsKey(nombreUsuario)) {
            Usuario u = usuarios.get(nombreUsuario);
            if (u.getContraseña().equals(contraseña)) {
                return u;
            }
        }
        throw new UsuarioNoEncontradoException("Usuario o contraseña incorrectos.");
    }

    @SuppressWarnings("unchecked")
    private void cargarUsuarios() {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(ARCHIVO_USUARIOS))) {
            usuarios = (HashMap<String, Usuario>) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            usuarios = new HashMap<>();
        }
        // Agrega un admin default si está vacío
        if (usuarios.isEmpty()) {
            Usuario admin = new Administrador("admin", "admin");
            usuarios.put("admin", admin);
            guardarUsuarios();
        }
    }

    private void guardarUsuarios() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(ARCHIVO_USUARIOS))) {
            out.writeObject(usuarios);
        } catch (IOException e) {
            System.out.println("Error guardando usuarios: " + e.getMessage());
        }
    }
}