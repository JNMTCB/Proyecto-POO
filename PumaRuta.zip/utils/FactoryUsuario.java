package utils;

import modelo.Administrador;
import modelo.Cliente;
import modelo.Usuario;

public class FactoryUsuario {
    public static Usuario crearUsuario(String tipo, String nombreUsuario, String contraseña) {
        if (tipo.equalsIgnoreCase("Administrador")) {
            return new Administrador(nombreUsuario, contraseña);
        } else {
            return new Cliente(nombreUsuario, contraseña);
        }
    }
}