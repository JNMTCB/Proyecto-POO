package vista;

import modelo.*;
import controlador.SistemaPumaRuta;
import persistencia.GestorUsuarios;
import excepciones.*;
import utils.FactoryUsuario;

import java.util.Scanner;

public class Main {
    private static GestorUsuarios gestorUsuarios = new GestorUsuarios();
    private static SistemaPumaRuta sistema = SistemaPumaRuta.getInstancia();

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Usuario usuarioActual = null;

        System.out.println("=== Bienvenido a PumaRuta ===");
        while (true) {
            System.out.println("\n1. Iniciar Sesión");
            System.out.println("2. Registrarse");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            String op = sc.nextLine();

            switch (op) {
                case "1":
                    usuarioActual = login(sc);
                    break;
                case "2":
                    registrar(sc);
                    break;
                case "3":
                    System.out.println("¡Hasta luego!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opción inválida");
            }

            while (usuarioActual != null) {
                if (usuarioActual.getTipo().equals("Administrador")) {
                    System.out.println("\n1. Buscar ruta");
                    System.out.println("2. Cerrar sesión");
                    System.out.print("Opción: ");
                    String adminOp = sc.nextLine();
                    if (adminOp.equals("1")) {
                        buscarRuta(sc);
                    } else if (adminOp.equals("2")) {
                        usuarioActual = null;
                    }
                } else {
                    System.out.println("\n1. Buscar ruta");
                    System.out.println("2. Cerrar sesión");
                    System.out.print("Opción: ");
                    String userOp = sc.nextLine();
                    if (userOp.equals("1")) {
                        buscarRuta(sc);
                    } else if (userOp.equals("2")) {
                        usuarioActual = null;
                    }
                }
            }
        }
    }

    private static Usuario login(Scanner sc) {
        System.out.print("Usuario: ");
        String user = sc.nextLine();
        System.out.print("Contraseña: ");
        String pass = sc.nextLine();
        try {
            Usuario u = gestorUsuarios.autenticar(user, pass);
            System.out.println("¡Bienvenido, " + u.getNombreUsuario() + " (" + u.getTipo() + ")!");
            return u;
        } catch (UsuarioNoEncontradoException e) {
            System.out.println("Error: " + e.getMessage());
            return null;
        }
    }

    private static void registrar(Scanner sc) {
        System.out.print("Elige tipo (Administrador/Cliente): ");
        String tipo = sc.nextLine();
        System.out.print("Usuario: ");
        String user = sc.nextLine();
        System.out.print("Contraseña: ");
        String pass = sc.nextLine();
        Usuario nuevo = FactoryUsuario.crearUsuario(tipo, user, pass);
        try {
            gestorUsuarios.registrarUsuario(nuevo);
            System.out.println("Registro exitoso.");
        } catch (UsuarioExistenteException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void buscarRuta(Scanner sc) {
        System.out.println("\nEntradas disponibles:");
        int i = 1;
        for (Entrada e : sistema.getEntradas()) {
            System.out.println(i + ". " + e.getNombre());
            i++;
        }
        System.out.print("Seleccione entrada (número): ");
        int idxEntrada = Integer.parseInt(sc.nextLine()) - 1;

        System.out.println("\nDestinos disponibles:");
        i = 1;
        for (Destino d : sistema.getDestinos()) {
            System.out.println(i + ". " + d.getNombre());
            i++;
        }
        System.out.print("Seleccione destino (número): ");
        int idxDestino = Integer.parseInt(sc.nextLine()) - 1;

        try {
            Ruta ruta = sistema.buscarRuta(
                    sistema.getEntradas().get(idxEntrada).getNombre(),
                    sistema.getDestinos().get(idxDestino).getNombre());
            System.out.println("\n--- Ruta recomendada ---");
            ruta.mostrarRuta();
            System.out.println("------------------------");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}