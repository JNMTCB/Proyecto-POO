package modelo;

public class Ruta implements IRuta {
    private Entrada entrada;
    private Destino destino;
    private Linea linea;
    private Parada paradaSubida;
    private Parada paradaBajada;
    private String alternativa;

    public Ruta(Entrada entrada, Destino destino, Linea linea, Parada subida, Parada bajada) {
        this.entrada = entrada;
        this.destino = destino;
        this.linea = linea;
        this.paradaSubida = subida;
        this.paradaBajada = bajada;
        this.alternativa = null;
    }

    public void setAlternativa(String alternativa) {
        this.alternativa = alternativa;
    }

    @Override
    public void mostrarRuta() {
        System.out.println("Tome la línea " + linea.getNombre() +
                " en la parada '" + paradaSubida.getNombre() +
                "'. Báje en la parada '" + paradaBajada.getNombre() + "'.");
        if (alternativa != null && !alternativa.isEmpty())
            System.out.println("Alternativa: " + alternativa);
    }
}