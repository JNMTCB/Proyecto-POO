package modelo;

public interface IRuta {
    void mostrarRuta();
}