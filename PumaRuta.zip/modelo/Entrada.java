package modelo;

public class Entrada {
    private String nombre;
    public Entrada(String nombre) { this.nombre = nombre; }
    public String getNombre() { return nombre; }
    @Override
    public String toString() { return nombre; }
}