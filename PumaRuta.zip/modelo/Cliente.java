package modelo;

public class Cliente extends Usuario {
    public Cliente(String nombreUsuario, String contraseña) {
        super(nombreUsuario, contraseña);
    }
    @Override
    public String getTipo() { return "Cliente"; }
}