package modelo;

import java.util.List;
import java.util.ArrayList;

public class Linea {
    private String nombre;
    private List<Parada> paradas;

    public Linea(String nombre) {
        this.nombre = nombre;
        this.paradas = new ArrayList<>();
    }

    public void agregarParada(Parada parada) {
        paradas.add(parada);
    }

    public String getNombre() { return nombre; }
    public List<Parada> getParadas() { return paradas; }

    @Override
    public String toString() { return nombre; }
}