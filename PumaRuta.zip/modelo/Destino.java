package modelo;

public class Destino {
    private String nombre;
    public Destino(String nombre) { this.nombre = nombre; }
    public String getNombre() { return nombre; }
    @Override
    public String toString() { return nombre; }
}